#Apollo2

# Instructions
1. Install all dependencies1
```bash
npm install
```
2. Run express server
```bash
node app.js
```
