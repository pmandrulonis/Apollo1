const express = require('express')
const bodyParser = require('body-parser')
const db = require("./database")
const app = express()

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: true,}))


app.get('/', function (req, res) {
  res.send('Were Going 2thamoon!')
})

app.get('/sun', function (req, res) {
  res.send('Were Going 2thasun!')
})

app.post('/signup', function(req, res ) {
  const email = req.query.email || ""
  if ( email ){
    db.addEmail(email)
    res.status(201).redirect(`/signup/${email}`)
  }
  else{
    res.send("No email address detected.")
  }
})

app.get('/signup/:email', function (req, res) {
  res.send(`Welcome ${req.params.email}! Keep your eye on your email for the latest updates!`)
})

app.listen(3001)
