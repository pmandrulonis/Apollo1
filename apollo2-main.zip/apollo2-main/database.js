const Pool = require('pg').Pool

// use .env file to store your database access credentials
require("dotenv").config({ path: "./.env" });

// connect to the database
const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
})

// function to add an email to the database
const addEmail = (email) => {

    // build the query with the given email address
    const query = `INSERT INTO emails (email) VALUES ('${email}');`

    // make query to the database
    pool.query(query, (error, results) => {
        if (error) {
            throw error
        }
    })
}

module.exports = {
    addEmail
}